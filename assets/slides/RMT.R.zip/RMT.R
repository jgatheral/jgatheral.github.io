#################################################################################################
# Wigner's semicirle law
#################################################################################################

n <- 5000
m <- array(rnorm(n^2),c(n,n))
m2 <- (m+t(m))/sqrt(2*n);# Make m symmetric
lambda <- eigen(m2, symmetric=T, only.values = T)
e <- lambda$values
hist(e,breaks=seq(-2.01,2.01,.02),xlab="Eigenvalues",freq=F,ylim=c(0,.4),xlim=c(-2,2),main=NA)
par(new=T)
curve(sqrt(4-x^2)/(pi*2),from=-2,to=2,lwd=2,col="red",ylim=c(0,0.4),xlab=NA,ylab=NA,xlim=c(-2,2))

# Now try uniform distribution
mu <- array(runif(n^2),c(n,n))
mu2 <-sqrt(12)*(mu+t(mu)-1)/sqrt(2*n)
lambdau <- eigen(mu2, symmetric=T, only.values = T)
eu <- lambdau$values
hist(eu,breaks=seq(-2.01,2.01,.02),main=NA,xlab="Eigenvalues",freq=F,ylim=c(0,.4),xlim=c(-2,2))
par(new=T)
curve(sqrt(4-x^2)/(pi*2),from=-2,to=2,lwd=2,col="magenta",ylim=c(0,0.4),xlab=NA,ylab=NA,xlim=c(-2,2))

# Theoretical density
rho <- function(lam,sig){
  if (abs(lam ) < 2*sig){sqrt(4*sig^2-lam^2)/(2*pi*sig^2)} 
  else 0
}
rho1 <- function(x){rho(x,1)}
rhov <- function(y){as.numeric(lapply(y,rho1))} # Note that function rho needs to be vectorized for curve to work!
curve(rhov(x),from=-2,to=2,col="red")

tr <- function(A){sum(A*diag(dim(A)[1]))}

#################################################################################################
# Marcenko-Pastur for correlation matrices
#################################################################################################

# Theoretical density
lamplus <- function(sig,q){sig^2*(1+1/q+2*sqrt(1/q))}
lamminus <- function(sig,q){sig^2*(1+1/q-2*sqrt(1/q))}

rhoq <- function(lam,sig,q){
  lp <- lamplus(sig,q)
  lm <- lamminus(sig,q)
  return((q/(2*sig^2*pi*lam))*sqrt(max(0,(lp-lam)*(lam-lm))))
}

# Now for the vectorized version
rhoqv <- function(y,sig,q){
  rhoqs <- function(x){rhoq(x,sig,q)}
  return(as.numeric(lapply(y,rhoqs)))
}

# Now we can plot the Marcenko-Pastur density
curve(rhoqv(x,1,5),from=0.0,to=5,col="red",xlab="Eigenvalues",ylab="Density",ylim=c(0,1),n=1000)
par(new=T)
curve(rhoqv(x,1,1),from=0.0,to=5,col="blue",xlab=NA,ylab=NA,ylim=c(0,1),n=1000)
par(new=T)
curve(rhoqv(x,1,2),from=0,to=5,col="green",xlab=NA,ylab=NA,ylim=c(0,1),n=1000)

#------------------------------------------------------------------------------------------------
# Let's now build a random correlation matrix (Wishart matrix) with Q=T/M=5
t <- 500
m <- 100
h <- array(rnorm(m*t),c(m,t))
e <- h %*% t(h)/t
lambdae <- eigen(e, symmetric=T, only.values = T)
ee <- lambdae$values
hist(ee,breaks=seq(0.05,3.05,.1),main=NA,xlab="Eigenvalues",freq=F,ylim=c(0,1),xlim=c(0,3))
par(new=T)
curve(rhoqv(x,1,5),from=0,to=3,lwd=2,col="red",ylim=c(0,1),xlab=NA,ylab=NA,xlim=c(0,3))

#------------------------------------------------------------------------------------------------
# Another ranodm correlation matrix (Wishart matrix) with Q=T/M=5 but with M only 10.
t <- 50
m <- 10
h <- array(rnorm(m*t),c(m,t))
e <- h %*% t(h)/t
lambdae <- eigen(e, symmetric=T, only.values = T)
ee <- lambdae$values
hist(ee,breaks=seq(0.2,3.2,.4),main=NA,xlab="Eigenvalues",freq=F,ylim=c(0,1),xlim=c(0,3))
par(new=T)
curve(rhoqv(x,1,5),from=0,to=3,lwd=2,col="red",ylim=c(0,1),xlab=NA,ylab=NA,xlim=c(0,3))

#------------------------------------------------------------------------------------------------
# Finally, a Wishart matrix with Q=T/M=5 and M=1000.
t <- 5000
m <- 1000
h <- array(rnorm(m*t),c(m,t))
e <- h %*% t(h)/t
lambdae <- eigen(e, symmetric=T, only.values = T)
ee <- lambdae$values
hist(ee,breaks=seq(0.01,3.01,.02),main=NA,xlab="Eigenvalues",freq=F,ylim=c(0,1),xlim=c(0,3))
par(new=T)
curve(rhoqv(x,1,5),from=0,to=3,lwd=2,col="red",ylim=c(0,1),xlab=NA,ylab=NA,xlim=c(0,3))

#################################################################################################
# Check residual after subtracting Identity matrix
#################################################################################################
m <- 1000
i <- diag(rep(1,m))
lambdaDiff <- eigen(e-i, symmetric=T, only.values = T)

# Check distribution of components
emin <- min(e-i)
emax <- max(e-i)
eb <- round(max(-emin,emax)/2,3)*2 + .001
hist(e-i,breaks=seq(-eb,eb,0.002),xlim=c(-eb,eb),freq=F,ylim=c(0,30))
s <- mean(sd(e-i)) #This gives sqrt(1/T)
curve(dnorm(x,mean=0,sd=sqrt(1/t)),from=-eb,to=eb,col="red",xlim=c(-eb,eb),add=T)

#################################################################################################
# Simulation of Tracy Widom distribution of largest eigenvalue
#################################################################################################

# Consider the first case above with M=100, T=500
# The largest eigenvalue of the sample matrix is
(lmax <- max(ee))
# and this compares to 
lamplus(1,5)
#2.094427
# We repeat the experiment many times to get the empirical distribution of lmax
nruns <- 10000
lmaxv <- as.numeric(nruns)
for (i in 1:nruns){
  t <- 500
  m <- 100
  h <- array(rnorm(m*t),c(m,t))
  e <- h %*% t(h)/t
  lambdae <- eigen(e, symmetric=T, only.values = T)
  lmaxv[i] <- max(lambdae$values)
}
hist(lmaxv,breaks=100,freq=F)
(lmean <- mean(lmaxv))
(lsd <- sd(lmaxv))


